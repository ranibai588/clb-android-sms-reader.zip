package com.clb.smsreader;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * BootReceiver — Phone restart hone ke baad bhi app kaam karta rahe.
 * Koi manual restart nahi chahiye.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {

            Log.d("CLB_Boot", "Phone reboot hua — SMS Reader ready hai");
            // SmsReceiver automatically registered hai AndroidManifest mein
            // Yahan kuch karne ki zaroorat nahi — receiver auto-active hoga
        }
    }
}
