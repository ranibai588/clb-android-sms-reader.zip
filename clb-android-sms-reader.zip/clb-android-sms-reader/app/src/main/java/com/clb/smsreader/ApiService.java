package com.clb.smsreader;

import android.util.Log;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * ApiService — WordPress REST API ko SMS data bhejta hai.
 * Koi external payment gateway nahi — sirf aapka apna WordPress server.
 *
 * API Endpoint: https://aapkisite.com/wp-json/clb-upi/v1/sms-credit
 */
public class ApiService {

    private static final String TAG = "CLB_ApiService";

    private final OkHttpClient client;
    private final SharedPref pref;

    public ApiService(SharedPref pref) {
        this.pref = pref;
        this.client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();
    }

    /**
     * WordPress API ko SMS send karta hai.
     * Server khud virtual account number se user dhundta hai aur wallet credit karta hai.
     *
     * @param sender    SMS bhejne wale ka number (bank number)
     * @param smsBody   Poora SMS text
     * @return          true = success, false = failure
     */
    public boolean sendSmsToWordPress(String sender, String smsBody) {
        String siteUrl   = pref.getSiteUrl();
        String secretKey = pref.getSecretKey();

        if (siteUrl.isEmpty() || secretKey.isEmpty()) {
            Log.e(TAG, "Site URL ya Secret Key set nahi hai");
            return false;
        }

        // Trailing slash ensure karo
        if (!siteUrl.endsWith("/")) {
            siteUrl += "/";
        }

        String apiUrl = siteUrl + "wp-json/clb-upi/v1/sms-credit";

        RequestBody body = new FormBody.Builder()
                .add("secret_key", secretKey)
                .add("sms_sender", sender)
                .add("sms_body", smsBody)
                .build();

        Request request = new Request.Builder()
                .url(apiUrl)
                .post(body)
                .addHeader("User-Agent", "CLB-SMS-Reader/1.0")
                .build();

        try {
            Response response = client.newCall(request).execute();
            String responseBody = response.body() != null ? response.body().string() : "";
            Log.d(TAG, "API Response (" + response.code() + "): " + responseBody);

            if (response.isSuccessful()) {
                return true;
            } else {
                Log.e(TAG, "API Error: HTTP " + response.code() + " — " + responseBody);
                return false;
            }

        } catch (IOException e) {
            Log.e(TAG, "Network Error: " + e.getMessage());
            return false;
        }
    }
}
